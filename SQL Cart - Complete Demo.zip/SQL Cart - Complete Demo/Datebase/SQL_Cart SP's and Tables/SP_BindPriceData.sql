CREATE PROCEDURE SP_BindPriceData
(
@UserID int
)
AS
SELECT * FROM tblCart D CROSS APPLY ( SELECT TOP 1 E.Name,Extension FROM tblProductImages E WHERE E.PID = D.PID) Name where D.UID = @UserID