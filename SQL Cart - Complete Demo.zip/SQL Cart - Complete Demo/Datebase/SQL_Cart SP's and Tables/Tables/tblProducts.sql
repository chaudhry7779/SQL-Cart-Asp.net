CREATE TABLE tblProducts(
	[PID] [int] IDENTITY(1,1) NOT NULL,
	[PName] [nvarchar](max) NULL,
	[PPrice] [money] NULL,
	[PSelPrice] [money] NULL,
	[PBrandID] [int] NULL,
	[PCategoryID] [int] NULL,
	[PSubCatID] [int] NULL,
	[PDescription] [nvarchar](max) NULL,
	[FreeDelivery] [int] NULL,
	[7DayRTN] [int] NULL,
	[COD] [int] NULL
)