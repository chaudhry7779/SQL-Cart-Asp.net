CREATE TABLE tblBrands(
	[BrandID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](500) NULL,
)