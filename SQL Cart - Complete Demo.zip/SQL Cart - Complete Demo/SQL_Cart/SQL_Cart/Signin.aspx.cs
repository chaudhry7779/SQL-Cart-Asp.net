﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SQL_Cart
{
    public partial class Signin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            divError.Visible = false;

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["SQL_Cart"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM tblUsers where Username=@username and Passw0rd=@pwd", con);
                cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@pwd", txtPw.Text);
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda1.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    Session["USERID"] = dt.Rows[0]["uid"].ToString();
                    Response.Cookies["UNAME"].Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies["UPWD"].Expires = DateTime.Now.AddDays(-1);
                    if (CheckBox1.Checked)
                    {
                        Response.Cookies["UNAME"].Value = txtUsername.Text;
                        Response.Cookies["UPWD"].Value = txtPw.Text;

                        Response.Cookies["UNAME"].Expires = DateTime.Now.AddDays(180);
                        Response.Cookies["UPWD"].Expires = DateTime.Now.AddDays(180);

                    }
                    else
                    {
                        Response.Cookies["UNAME"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies["UPWD"].Expires = DateTime.Now.AddDays(-1);
                    }
                    string Utype;
                    Utype = dt.Rows[0]["UserType"].ToString().Trim();
                    if (Utype == "User")
                    {
                        Session["USEREMAIL"] = dt.Rows[0]["Email"].ToString();
                        Session["getFullName"] = dt.Rows[0]["Fullname"].ToString();
                        Session["Mobile"] = dt.Rows[0]["Mobile"].ToString();
                        Session["LoginType"] = "User";
                        Session["Username"] = txtUsername.Text;
                        if (Request.QueryString.Count == 1)
                        {
                            if (Request.QueryString["rurl"] == "PID")
                            {
                                string myPID = Session["ReturnPID"].ToString();
                                Response.Redirect("~/ProductView.aspx?PID=" + myPID + "");
                            }
                        }
                        else if (Request.QueryString.Count == 2)
                        {
                            // if you want to setup-up return url using 2 QueryStrings
                        }
                        else if (Request.QueryString.Count == 0)
                        {
                            Response.Redirect("~/Products.aspx");
                        }
                    }
                    if (Utype == "Admin")
                    {
                        Session["LoginType"] = "Admin";
                        Session["Username"] = txtUsername.Text;
                        Response.Redirect("~/AdminHome.aspx");
                    }
                }
                else
                {
                    divError.Visible = true;
                }
                clr();
                con.Close();
            }
        }

        private void clr()
        {
            txtUsername.Text = string.Empty;
            txtPw.Text = string.Empty;
            txtUsername.Focus();
        }
    }
}